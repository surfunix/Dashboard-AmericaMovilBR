#!/bin/bash
# Atualiza gestao/index.html e view/index.html no bucket dashboard-claro.
# Uso: bash atualizar-dashboards.sh <pasta com gestao/ e view/>
# Antes de subir, guarda as versões atuais do bucket em ~/dashboard-fy27/backup-html/<data-hora>/
set -euo pipefail

BKT=dashboard-claro
SRC=${1:-.}
STAMP=$(date +%Y%m%d-%H%M%S)
BK=~/dashboard-fy27/backup-html/$STAMP

for d in gestao view; do
  [ -f "$SRC/$d/index.html" ] || { echo "ERRO: não encontrei $SRC/$d/index.html"; exit 1; }
done

echo "1) Backup das versões atuais do bucket em $BK"
mkdir -p "$BK/gestao" "$BK/view"
for d in gestao view; do
  oci os object get -bn $BKT --name $d/index.html --file "$BK/$d/index.html" >/dev/null
done

echo "2) Enviando as versões novas"
for d in gestao view; do
  oci os object put -bn $BKT --name $d/index.html --file "$SRC/$d/index.html" \
    --content-type "text/html; charset=utf-8" --cache-control "no-cache, no-store, must-revalidate" --force >/dev/null
  echo "   $d/index.html enviado"
done

echo "3) Conferindo"
for d in gestao view; do
  CT=$(oci os object head -bn $BKT --name $d/index.html --query '"content-type"' --raw-output)
  LOCAL=$(md5sum "$SRC/$d/index.html" | cut -d' ' -f1)
  oci os object get -bn $BKT --name $d/index.html --file /tmp/check-$d.html >/dev/null
  REMOTO=$(md5sum /tmp/check-$d.html | cut -d' ' -f1); rm -f /tmp/check-$d.html
  [ "$LOCAL" = "$REMOTO" ] && OK="conteúdo igual" || OK="CONTEÚDO DIFERENTE"
  echo "   $d/index.html -> $CT | $OK"
done

echo
echo "Pronto. Recarregue as páginas com Cmd+Shift+R."
echo "Para desfazer: bash atualizar-dashboards.sh $BK"
